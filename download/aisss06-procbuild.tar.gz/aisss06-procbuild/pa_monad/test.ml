let bind l f = List.concat (List.map f l)
let return x = [x]

let li = perform
  (a,c) <-- [1,2;2,3;3,4];
  b <-- [4;5;6];
  return (c+b)
